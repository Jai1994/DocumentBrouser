package com.adil.controller;

import java.io.IOException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;

//import com.jfoenix.controls.JFXTextField;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;

public class DocBrowser {

	String url_google = "https://www.google.com/search?q=";

	String url_yahoo = "https://in.search.yahoo.com/search?q=";
	String url_bing = "https://www.bing.com/search?q=";
	String url_custom;

	@FXML
	private StackPane mainbrowserStackPane;
	@FXML
	private AnchorPane mainbrowserAnchorPane;
	@FXML
	private JFXButton mainsearchbtn;
	@FXML
	private JFXTextField mainserachfield;
	@FXML
	private TextField customtextfield;
	@FXML
	private ChoiceBox<String> mychoicebox;
	@FXML
	private RadioButton google;

	@FXML
	private RadioButton bing;

	@FXML
	private RadioButton yahoo;

	@FXML
	private RadioButton custom;
	ToggleGroup tg = new ToggleGroup();
	FontAwesomeIcon icon = null;
	Elements webSitesLinks;
	JFXButton DOWNLOAD_BTN = null;

	public void initialize() {

		mychoicebox.getItems().add("PDF");
		mychoicebox.getItems().add("WORD");
		customtextfield.setVisible(false);
		google.setToggleGroup(tg);
		bing.setToggleGroup(tg);
		yahoo.setToggleGroup(tg);
		custom.setToggleGroup(tg);

	}
	ArrayList<String> link_array = new ArrayList<String>();
	@FXML
	void mainsearchcall(ActionEvent event) {

		// System.out.print("mainsearchcall method");
		String mainsearchinput, radiobtninput, doctypeinput;

		mainsearchinput = mainserachfield.getText();

		RadioButton selectedRadioButton = (RadioButton) tg.getSelectedToggle();
		radiobtninput = selectedRadioButton.getText();
		doctypeinput = mychoicebox.getValue();
//		System.out.println(radiobtninput);
		String encoding = "UTF-8";
		if (radiobtninput.equals("Google")) {
			radiobtninput = url_google;
//			System.out.println("google:"+radiobtninput);

			try {
//				processCall(mainsearchinput + ":" + doctypeinput, radiobtninput);
				URL obj = new URL(radiobtninput);
				System.out.println(obj);
				Document duckduckgo = Jsoup
						.connect(obj + URLEncoder.encode(mainsearchinput + ":" + doctypeinput, encoding)).get();
//				System.out.println(duckduckgo);
//				webSitesLinks = duckduckgo.getElementsByTag("cite");
				webSitesLinks = duckduckgo.getElementsByClass("r");
				webSitesLinks = webSitesLinks.select("a[href]");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (radiobtninput.equals("Yahoo")) {
			radiobtninput = url_yahoo;
			try {
//				processCall( "filetype:"+doctypeinput+" "+mainsearchinput, radiobtninput);
				URL obj = new URL(radiobtninput);
				System.out.println(obj);
				Document duckduckgo = Jsoup
						.connect(obj + URLEncoder.encode("filetype:" + doctypeinput + " " + mainsearchinput, encoding))
						.get();
				webSitesLinks = duckduckgo.getElementsByClass(" fz-ms fw-m fc-12th wr-bw lh-17");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (radiobtninput.equals("Bing")) {
			radiobtninput = url_bing;
			try {
//				processCall("filetype:"+doctypeinput+" "+mainsearchinput, radiobtninput);
				URL obj = new URL(radiobtninput);
				System.out.println(obj);
				Document duckduckgo = Jsoup
						.connect(obj + URLEncoder.encode("filetype:" + doctypeinput + " " + mainsearchinput, encoding))
						.get();
//				System.out.println(duckduckgo);
				webSitesLinks = duckduckgo.getElementsByClass("b_algo");
				webSitesLinks = webSitesLinks.select("a[href]");
//				webSitesLinks =duckduckgo.select("cite").remove();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			url_custom = customtextfield.getText();// get url from custom text field
		}

		try {
			System.out.println("Inside datatable");
			Parent root;
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/adil/uifxml/DataTableContainer.fxml"));
			root = (Parent) fxmlLoader.load();
			Scene scene = mainsearchbtn.getScene();
			root.translateXProperty().set(scene.getWidth());
			mainbrowserStackPane.getChildren().add(root);
//
//			DOWNLOAD_BTN = new JFXButton();
////			DOWNLOAD_BTN.setId((String));
//			DOWNLOAD_BTN.setMinWidth(10);
//			DOWNLOAD_BTN.setMaxHeight(10);
//			DOWNLOAD_BTN.setButtonType(ButtonType.RAISED);
//			
//			icon = new FontAwesomeIcon();
//			icon.setIcon(de.jensd.fx.glyphs.fontawesome.FontAwesomeIconName.DOWNLOAD);
//			icon.setSize("17px");
//			icon.setFill(Paint.valueOf("#0bd3e3"));
//			DOWNLOAD_BTN.setGraphic(icon);
			
			TableController tableController = fxmlLoader.getController();
			if (!webSitesLinks.isEmpty()) {

//				int i = 0;
				for (Element link : webSitesLinks) {
					System.out.println("my link: " + link);
					if (link.attr("abs:href").endsWith(".pdf")) {
						link_array.add(link.attr("abs:href"));
//						System.out.println(link_array.get(i));
//						i++;
						System.out.println("one end");

						System.out.println("link array :" + link_array);
					}else if(link.text().endsWith(".pdf")){
						link_array.add("http://"+link.text());
					}
				}
				tableController.set_Table_Data(link_array);

			} else {
				System.out.println("Empty links");
			}

			Timeline timeline = new Timeline();
			javafx.animation.KeyValue keyvalue = new javafx.animation.KeyValue(root.translateXProperty(), 0,
					Interpolator.EASE_IN);
			KeyFrame keyframe = new KeyFrame(Duration.millis(1), keyvalue);
			timeline.getKeyFrames().add(keyframe);
			timeline.setOnFinished(eventtoremovefirstscene -> {
				mainbrowserStackPane.getChildren().remove(mainbrowserAnchorPane);
			});

			timeline.play();
			System.out.println("Website links ::::" + webSitesLinks);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	

	@FXML
	void googlecall(ActionEvent event) {
		if (google.isSelected()) {
			customtextfield.setVisible(false);
		}
	}

	@FXML
	void bingcall(ActionEvent event) {
		if (bing.isSelected()) {
			customtextfield.setVisible(false);
		}
	}

	@FXML
	void yahoocall(ActionEvent event) {
		if (yahoo.isSelected()) {
			customtextfield.setVisible(false);
		}
	}

	@FXML
	void customInput(ActionEvent event) {

		customtextfield.setVisible(true);

	}

}
