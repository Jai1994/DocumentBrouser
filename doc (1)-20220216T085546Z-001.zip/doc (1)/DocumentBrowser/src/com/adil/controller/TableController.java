package com.adil.controller;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.net.ssl.HttpsURLConnection;



import com.adil.ModelTable.ModelTable;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXButton.ButtonType;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
//import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

public class TableController implements Initializable {
	@FXML
	private TableView<ModelTable> tableview;

	@FXML
	private TableColumn<ModelTable, String> table_filename;

	@FXML
	private TableColumn<ModelTable, Integer> table_filename_size;

	@FXML
	private TableColumn<ModelTable, String> table_filename_rating;

	@FXML
	private TableColumn<ModelTable, String> table_filename_downloaded;

	@FXML
	private TableColumn<ModelTable, String> table_filename_url;

	@FXML
	private TableColumn<ModelTable, String> table_filename_download;
	// int num=0;
	final ObservableList<ModelTable> data = FXCollections.observableArrayList();
	FontAwesomeIcon icon = null;

	public TableController() {
		System.out.println("default constructor");

	}

	JFXButton DOWNLOAD_BTN = null;

	public void set_Table_Data(ArrayList<String> website_links) {
		double size = 0;
		DecimalFormat df2 = new DecimalFormat("#.##");
//		friend_chat_call_BTN.setGraphic(icon);

		System.out.println("Inside  set_Table_Data");
		System.out.println("website_links111" + website_links);
//		website_links.forEach(link -> data.add(new ModelTable("hello", "20", "huioopppp", "jjjj", link.text(),DOWNLOAD_BTN)));
		for (int i = 0; i < website_links.size(); i++) {

			DOWNLOAD_BTN = new JFXButton();
			DOWNLOAD_BTN.setId((String) website_links.get(i));
			DOWNLOAD_BTN.setMinWidth(10);
			DOWNLOAD_BTN.setMaxHeight(10);
			DOWNLOAD_BTN.setButtonType(ButtonType.RAISED);

			icon = new FontAwesomeIcon();
			icon.setIcon(de.jensd.fx.glyphs.fontawesome.FontAwesomeIconName.DOWNLOAD);
			icon.setSize("17px");
			icon.setFill(Paint.valueOf("#0bd3e3"));
			DOWNLOAD_BTN.setGraphic(icon);

			String file_name[] = website_links.get(i).split("/");
			String string_url = "";
			for (String string : file_name) {
//				if (string.equals("\u203A")) {
//					string_url=string_url+"/";
//					System.out.println(""+string_url);
//					System.out.println("Found this > ");
//				} else {
//					System.out.println("not this > found");
//					string_url = string_url.concat(string);
//				}
//				System.out.println(string);

			}
//			System.out.println("My url " + string_url);

//			System.out.println("web----"+website_links.get(i).text());
//			System.out.println("web111"+website_links.get(i).text().replace(" ","").replace(">", "/"));
//			System.out.println("JSOUP---------"+ website_links.get(i).text().replaceAll("<.*?>" , " "));
			try {
				// https://www.tutorialspoint.com/cprogramming/cprogramming_tutorial
				// "www.tutorialspoint.com/cprogramming/cprogramming_tutorial"
				size = getFileSize(new URL(website_links.get(i)));
				System.out.println("url is 111:"+website_links.get(i));
				size = size / (1024 * 1024);

			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			data.add(new ModelTable(file_name[file_name.length - 1], df2.format(size) + " MB", "huioopppp", "jjjj",
					website_links.get(i), DOWNLOAD_BTN));
		}

		tableview.setItems(data);
	}

	private static int getFileSize(URL url) {
		System.out.println("url is22 :"+url);
		URLConnection conn = null;
		try {
			System.out.println("url is33 :"+url);
			conn = url.openConnection();
			if (conn instanceof HttpURLConnection) {
				((HttpURLConnection) conn).setRequestMethod("HEAD");
				System.out.println("Inside HEAD req");
			}
			conn.getInputStream();
			System.out.println(conn.getContentLength());
			return conn.getContentLength();
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn instanceof HttpURLConnection) {
				((HttpURLConnection) conn).disconnect();
			}
		}
	}
	Stage primaryStagepreview=null;
	public void initialize(URL location, ResourceBundle resource) {
//		
//		data.add(new ModelTable("hello", "20", "huioopppp", "jjjj", "jjjjgggggg"));
//		data.add(new ModelTable("hello", "20", "huioopppp", "jjjj", "jjjjgggggg"));
//		data.add(new ModelTable("hello", "20", "huioopppp", "jjjj", "jjjjgggggg"));
//		
		System.out.println("Initialize block");
		table_filename.setCellValueFactory(new PropertyValueFactory<>("FileName"));
		table_filename_size.setCellValueFactory(new PropertyValueFactory<>("FileSize"));
		table_filename_rating.setCellValueFactory(new PropertyValueFactory<>("FileRating"));
		table_filename_downloaded.setCellValueFactory(new PropertyValueFactory<>("FileDownlaoded"));
		table_filename_url.setCellValueFactory(new PropertyValueFactory<>("FileURL"));

		tableview.getSelectionModel().setCellSelectionEnabled(true);

		final ObservableList<TablePosition> selectedCells = tableview.getSelectionModel().getSelectedCells();

		selectedCells.addListener(new ListChangeListener<TablePosition>() {
			@Override
			public void onChanged(Change change) {
				for (TablePosition pos : selectedCells) {
					if (pos.getTableColumn().getText().equals("Preview")) {
						pos.getTableColumn().setStyle("-fx-selection-bar: red;");
						if(primaryStagepreview==null) {
							
							System.out.println("Cell selected in row " + pos.getRow() + " and column "
									+ pos.getTableColumn().getText());
							loadPreview();
						}else {
							primaryStagepreview.close();
							loadPreview();
							System.out.println("Cell selected in row " + pos.getRow() + " and column "
									+ pos.getTableColumn().getText());
						}

						

					}

				}
			}
		});
//		});

		table_filename_download.setCellValueFactory(new PropertyValueFactory<>("FileDownlaod"));

	}

	public void loadPreview() {
		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("/com/adil/uifxml/PreView.fxml"));
			Scene scene = new Scene(root);
			primaryStagepreview = new Stage();
			primaryStagepreview.setScene(scene);
			primaryStagepreview.show();
			primaryStagepreview.setOnCloseRequest(new EventHandler<WindowEvent>() {
				    @Override
				    public void handle(WindowEvent e) {
				    	System.out.println("Closed by user");
				    	primaryStagepreview=null;
//				     Platform.exit();
//				     System.exit(0);
				    }
				  });
//			primaryStagepreview.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Parent root = loader.load();
		
	}
	
	

	@FXML
	private JFXButton tablebackbtn;
	@FXML
	private StackPane datatableStackPane;
	@FXML
	private AnchorPane datatableAnchorPane;

	@FXML
	void gotomainbrowser(ActionEvent event) {
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource("/com/adil/uifxml/MainBrowser.fxml"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scene scene = tablebackbtn.getScene();
		root.translateXProperty().set(scene.getWidth());
		datatableStackPane.getChildren().add(root);

		Timeline timeline = new Timeline();
		javafx.animation.KeyValue keyvalue = new javafx.animation.KeyValue(root.translateXProperty(), 0,
				Interpolator.EASE_IN);
		KeyFrame keyframe = new KeyFrame(Duration.millis(1), keyvalue);
		timeline.getKeyFrames().add(keyframe);
		timeline.setOnFinished(eventtoremovefirstscene -> {
			datatableStackPane.getChildren().remove(datatableAnchorPane);
		});
		timeline.play();
	}

}
